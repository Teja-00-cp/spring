package com.example.hosptiAl.Exception;

public class PatientError extends RuntimeException{
	
	public PatientError(String sta) {
		super(sta);
	}
	public PatientError() {
		
	}

}
