package com.example.hosptiAl;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HosptiAlApplicationTests {

	@Test
	void contextLoads() {
	}

}
